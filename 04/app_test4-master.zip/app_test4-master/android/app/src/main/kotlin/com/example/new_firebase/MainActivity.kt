package com.example.new_firebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
